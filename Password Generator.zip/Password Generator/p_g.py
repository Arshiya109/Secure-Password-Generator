import tkinter as tk
from tkinter import messagebox
import random
import string
import pyperclip

def generate_password():
    length = password_length.get()
    characters = ''
   
    if use_uppercase.get():
        characters += string.ascii_uppercase
    if use_lowercase.get():
        characters += string.ascii_lowercase
    if use_digits.get():
        characters += string.digits
    if use_special.get():
        characters += string.punctuation

    if not characters:
        messagebox.showwarning("Selection Error", "Please select at least one character type.")
        return

    password = ''.join(random.choice(characters) for _ in range(length))
    password_entry.delete(0, tk.END)
    password_entry.insert(0, password)
   
    # Update the strength bar according to the password length
    strength = min(length / 20.0, 1.0)
    strength_bar.coords(fill_rect, (0, 0, strength * 200, 20))
   
    # Changing the color based on strength of the password
    if strength < 0.4:
        strength_bar.itemconfig(fill_rect, fill="red")
    elif strength < 0.7:
        strength_bar.itemconfig(fill_rect, fill="orange")
    else:
        strength_bar.itemconfig(fill_rect, fill="green")
        

def copy_password():
    password = password_entry.get()
    if password:
        pyperclip.copy(password)
        messagebox.showinfo("Copied", "Password copied to the clipboard!")
    else:
        messagebox.showwarning("Copy Error", "There is no password to be copied!")

# GUI Window
root = tk.Tk()
root.title("Password Generator")
root.geometry("450x400")
root.configure(bg="#f0f8ff")  # Light blue background

# Title 
tk.Label(root, text="🔒Password Generator", font=("Helvetica", 16, "bold"), fg="#1f4e79", bg="#f0f8ff").pack(pady=10)

# Frame for the checkboxes
options_frame = tk.Frame(root, bg="white", bd=2, relief="groove")
options_frame.pack(pady=10, padx=20, fill="x")

use_uppercase = tk.BooleanVar(value=True)
use_lowercase = tk.BooleanVar(value=True)
use_digits = tk.BooleanVar(value=True)
use_special = tk.BooleanVar(value=True)

tk.Checkbutton(options_frame, text="Include A-Z", variable=use_uppercase, bg="white", font=("Arial", 10)).grid(row=0, column=0, padx=10, pady=5)
tk.Checkbutton(options_frame, text="Include a-z", variable=use_lowercase, bg="white", font=("Arial", 10)).grid(row=0, column=1, padx=10, pady=5)
tk.Checkbutton(options_frame, text="Include 0-9", variable=use_digits, bg="white", font=("Arial", 10)).grid(row=1, column=0, padx=10, pady=5)
tk.Checkbutton(options_frame, text="Include Special Characters", variable=use_special, bg="white", font=("Arial", 10)).grid(row=1, column=1, padx=10, pady=5)

# Password Length
length_frame = tk.Frame(root, bg="#f0f8ff")
length_frame.pack(pady=5)

tk.Label(length_frame, text="Password Length:", font=("Arial", 11), bg="#f0f8ff").pack(side="left")
password_length = tk.IntVar(value=14)
tk.Entry(length_frame, textvariable=password_length, width=5, font=("Arial", 11)).pack(side="left", padx=5)

# Strength Bar
tk.Label(root, text="Password Strength", bg="#f0f8ff", font=("Arial", 10)).pack(pady=(15, 0))
strength_bar = tk.Canvas(root, width=200, height=20, bg="white", bd=1, relief='sunken')
strength_bar.pack(pady=3)
fill_rect = strength_bar.create_rectangle(0, 0, 0, 20, fill="green")

# Password Display
password_entry = tk.Entry(root, font=("Courier", 14), width=28, justify="center", bd=2, relief="sunken")
password_entry.pack(pady=10)

# Buttons Frame
btn_frame = tk.Frame(root, bg="#f0f8ff")
btn_frame.pack(pady=10)

tk.Button(btn_frame, text="Generate", command=generate_password, bg="#4CAF50", fg="white", font=("Arial", 11, "bold"), width=15).grid(row=0, column=0, padx=10)
tk.Button(btn_frame, text="Copy", command=copy_password, bg="#1E90FF", fg="white", font=("Arial", 11, "bold"), width=10).grid(row=0, column=1, padx=10)

# Footer
tk.Label(root, text="Designed with 💡 in Python Tkinter", font=("Arial", 8), bg="#f0f8ff", fg="gray").pack(side="bottom", pady=5)

root.mainloop()